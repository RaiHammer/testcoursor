# Слайдер отзывов inSales + Яндекс (DanForge)

**Handle:** `danforge_reviews_slider`  
**Папка:** `projects/df_reviews_slider/`  
**Статус:** упаковка завершена — пилот → публикация  
**Дистрибутив:** `dist/danforge-reviews-slider.zip`

Объединённый слайдер отзывов на главной: товары из inSales + компания из Яндекс Карт. Данные собирает CLI `get-reviews`, виджет только показывает слайды.

---

## Состав

```
df_reviews_slider/
├── widget/          # gen-4 виджет (Swiper)
├── cli/             # get_reviews.py — сбор и генерация Liquid
├── output/          # сгенерированные файлы (после запуска CLI)
└── README.md
```

---

## Быстрый старт (установщику)

### 1. Виджет

1. Админка → Виджеты → создать → загрузить файлы из `widget/`
2. Добавить виджет **«Слайдер отзывов DanForge»** на главную (список content)
3. Заполнить заголовок, ссылку «Оставить отзыв»

### 2. CLI (на вашем ПК)

```bash
cd cli
pip install -r requirements.txt
copy config.example.json config.json
# заполнить shop, api_key, password, yandex_org_url
python get_reviews.py
python get_reviews.py -u   # + загрузка сниппета в тему
```

**Демо без API:**
```bash
python get_reviews.py --demo
```

### 3. Сниппет в теме

CLI создаёт `output/danforge_reviews_slides.liquid`.

- С флагом `-u` — загрузка в `snippets/danforge_reviews_slides.liquid` темы
- Без `-u` — вручную: Редактор темы → Snippets → вставить содержимое файла

### 4. Проверка

Открыть главную → слайдер с отзывами, точки пагинации, автопрокрутка.

---

## config.json

| Поле | Описание |
|------|----------|
| `shop` | `my-shop.myinsales.ru` |
| `api_key` / `password` | Ключ API (Приложения → Разработчикам) |
| `theme_id` | ID темы (null = опубликованная тема) |
| `yandex_org_url` | URL организации на Яндекс Картах |
| `yandex_reviews_file` | JSON-файл отзывов Яндекса (fallback) |
| `sample_count` | Сколько отзывов в слайдер (default 20) |
| `insales_ratio` | Доля inSales 0–1 (default 0.5) |

---

## Обновление отзывов

Раз в месяц или по запросу клиента:

```bash
python get_reviews.py -u
```

Сервер не нужен — утилита на вашем компьютере.

---

## Яндекс: если парсер не сработал

Публичного API нет. Если автопарсинг не сработал:

1. Экспортируйте отзывы в JSON (массив `{name, text, stars, icon_href}`)
2. Укажите `"yandex_reviews_file": "yandex.json"` в config
3. Запустите CLI снова

---

## Требования

- inSales, generation 4, Swiper на теме (библиотека `swiper` в info.json)
- API-ключ с доступом к отзывам и темам
- Python 3.10+

---

## Лицензия

Коммерческая. Один магазин — одна лицензия.

**DanForge** · https://danforge.ru
