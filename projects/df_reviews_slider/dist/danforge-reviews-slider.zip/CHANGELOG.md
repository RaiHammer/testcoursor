# CHANGELOG

## v1.0.1 — упаковка

- Kwork + Tilda гайды, обложки, zip дистрибутив
- `yandex.example.json`

## [1.0.0] — 2026-07-09

### MVP
- Виджет `danforge_reviews_slider` (Swiper, адаптив)
- CLI `get_reviews.py`: inSales Admin API, Яндекс (парсинг + JSON fallback)
- Генерация `danforge_reviews_slides.liquid`, кэш JSON
- Загрузка сниппета в тему (`-u`)
- Случайный срез отзывов, demo-режим (`--demo`)
