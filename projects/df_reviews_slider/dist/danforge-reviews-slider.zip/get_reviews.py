#!/usr/bin/env python3
"""
DanForge get-reviews — сбор отзывов inSales + Яндекс, генерация Liquid-сниппета.

Автор: DanForge · https://danforge.ru
"""
from __future__ import annotations

import argparse
import json
import random
import re
import sys
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

SNIPPET_KEY = "snippets/danforge_reviews_slides.liquid"
USER_AGENT = "DanForge-get-reviews/1.0 (+https://danforge.ru)"


@dataclass
class Review:
    author: str
    content: str
    rating: int
    source: str  # insales | yandex
    avatar_url: str | None = None
    created_at: str | None = None


@dataclass
class Config:
    shop: str
    api_key: str
    password: str
    theme_id: int | None = None
    yandex_org_url: str | None = None
    yandex_reviews_file: str | None = None
    sample_count: int = 20
    insales_ratio: float = 0.5
    min_text_length: int = 10
    output_dir: str = "output"
    upload_avatars: bool = False


def load_config(path: Path) -> Config:
    data = json.loads(path.read_text(encoding="utf-8"))
    return Config(
        shop=data["shop"].replace("https://", "").replace("http://", "").strip("/"),
        api_key=data["api_key"],
        password=data["password"],
        theme_id=data.get("theme_id"),
        yandex_org_url=data.get("yandex_org_url"),
        yandex_reviews_file=data.get("yandex_reviews_file"),
        sample_count=int(data.get("sample_count", 20)),
        insales_ratio=float(data.get("insales_ratio", 0.5)),
        min_text_length=int(data.get("min_text_length", 10)),
        output_dir=data.get("output_dir", "output"),
        upload_avatars=bool(data.get("upload_avatars", False)),
    )


def insales_session(cfg: Config) -> tuple[str, tuple[str, str]]:
    base = f"https://{cfg.shop}"
    return base, (cfg.api_key, cfg.password)


def fetch_insales_reviews(cfg: Config) -> list[Review]:
    base, auth = insales_session(cfg)
    reviews: list[Review] = []
    page = 1
    per_page = 100

    while True:
        resp = requests.get(
            f"{base}/admin/reviews.json",
            auth=auth,
            params={"page": page, "per_page": per_page},
            headers={"User-Agent": USER_AGENT},
            timeout=60,
        )
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            break

        for item in batch:
            if not item.get("published"):
                continue
            content = (item.get("content") or "").strip()
            if len(content) < cfg.min_text_length:
                continue
            avatar = None
            img = item.get("first_image") or {}
            thumb = img.get("thumb_url") or img.get("small_url")
            if thumb and "no_image" not in thumb:
                avatar = thumb if thumb.startswith("http") else f"{base}{thumb}"

            reviews.append(
                Review(
                    author=(item.get("author") or "Покупатель").strip(),
                    content=content,
                    rating=normalize_stars(item.get("rating")),
                    source="insales",
                    avatar_url=avatar,
                    created_at=item.get("created_at"),
                )
            )

        if len(batch) < per_page:
            break
        page += 1

    return reviews


def normalize_stars(rating: Any) -> int:
    if rating is None:
        return 5
    try:
        value = float(rating)
    except (TypeError, ValueError):
        return 5
    if value > 5:
        value = round(value / 2)
    return max(1, min(5, round(value)))


def stars_html(rating: int) -> str:
    rating = max(1, min(5, rating))
    return "★" * rating + "☆" * (5 - rating)


def liquid_escape(text: str) -> str:
    return (
        text.replace("\\", "\\\\")
        .replace('"', "&quot;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\n", " ")
        .strip()
    )


def load_yandex_from_file(path: Path) -> list[Review]:
    data = json.loads(path.read_text(encoding="utf-8"))
    items = data if isinstance(data, list) else data.get("reviews", [])
    result: list[Review] = []
    for item in items:
        content = (item.get("text") or item.get("content") or "").strip()
        if len(content) < 5:
            continue
        result.append(
            Review(
                author=(item.get("name") or item.get("author") or "Клиент").strip(),
                content=content,
                rating=normalize_stars(item.get("stars") or item.get("rating")),
                source="yandex",
                avatar_url=item.get("icon_href") or item.get("avatar_url"),
                created_at=item.get("date"),
            )
        )
    return result


def fetch_yandex_reviews(cfg: Config) -> list[Review]:
    if cfg.yandex_reviews_file:
        return load_yandex_from_file(Path(cfg.yandex_reviews_file))

    if not cfg.yandex_org_url:
        return []

    url = cfg.yandex_org_url.rstrip("/")
    if "/reviews" not in url:
        url = f"{url}/reviews/"

    resp = requests.get(
        url,
        headers={"User-Agent": USER_AGENT, "Accept-Language": "ru-RU,ru;q=0.9"},
        timeout=60,
    )
    resp.raise_for_status()
    html = resp.text

    reviews = parse_yandex_html(html)
    if not reviews:
        print(
            "Предупреждение: не удалось распарсить отзывы Яндекса автоматически. "
            "Экспортируйте отзывы в JSON и укажите yandex_reviews_file в config.",
            file=sys.stderr,
        )
    return reviews


def parse_yandex_html(html: str) -> list[Review]:
    """Пробует извлечь отзывы из встроенного JSON на странице Яндекс Карт."""
    reviews: list[Review] = []
    patterns = [
        r'"review"\s*:\s*\{[^}]*"text"\s*:\s*"([^"]+)"[^}]*"author"\s*:\s*\{[^}]*"name"\s*:\s*"([^"]+)"',
        r'"text"\s*:\s*"((?:\\.|[^"\\])*)"\s*,\s*"rating"\s*:\s*(\d+(?:\.\d+)?)',
    ]

    for block in re.findall(r'"reviews"\s*:\s*\[(.*?)\]\s*,\s*"[a-zA-Z_]+"', html, re.S):
        for name, text, stars in re.findall(
            r'"author"\s*:\s*\{[^}]*"name"\s*:\s*"([^"]+)"[^}]*\}[^}]*"text"\s*:\s*"((?:\\.|[^"\\])*)"[^}]*"rating"\s*:\s*(\d+(?:\.\d+)?)',
            block,
        ):
            text_clean = bytes(text, "utf-8").decode("unicode_escape")
            reviews.append(
                Review(
                    author=name,
                    content=text_clean.replace("\\n", " ").strip(),
                    rating=normalize_stars(float(stars)),
                    source="yandex",
                )
            )

    if reviews:
        return reviews

    # Fallback: простые пары имя + текст из schema.org
    for match in re.finditer(
        r'"author"\s*:\s*"([^"]+)"[^}]{0,200}?"reviewBody"\s*:\s*"((?:\\.|[^"\\])*)"',
        html,
    ):
        author, text = match.groups()
        text_clean = bytes(text, "utf-8").decode("unicode_escape")
        if len(text_clean) >= 10:
            reviews.append(
                Review(
                    author=author,
                    content=text_clean,
                    rating=5,
                    source="yandex",
                )
            )

    return reviews


def sample_reviews(
    insales: list[Review], yandex: list[Review], cfg: Config
) -> list[Review]:
    count = cfg.sample_count
    insales_n = min(len(insales), round(count * cfg.insales_ratio))
    yandex_n = min(len(yandex), count - insales_n)

    if insales_n + yandex_n < count:
        insales_n = min(len(insales), count - yandex_n)
        yandex_n = min(len(yandex), count - insales_n)

    picked = random.sample(insales, insales_n) if insales_n else []
    picked += random.sample(yandex, yandex_n) if yandex_n else []

    remaining = count - len(picked)
    pool = [r for r in insales + yandex if r not in picked]
    if remaining > 0 and pool:
        picked += random.sample(pool, min(remaining, len(pool)))

    random.shuffle(picked)
    return picked


def render_slide(review: Review) -> str:
    author = liquid_escape(review.author)
    content = liquid_escape(review.content)
    stars = stars_html(review.rating)
    source_label = "InSales" if review.source == "insales" else "Яндекс"

    avatar_html = ""
    if review.avatar_url:
        avatar_html = (
            f'<div class="df-reviews__avatar">'
            f'<img src="{liquid_escape(review.avatar_url)}" alt="" loading="lazy" width="72" height="72">'
            f"</div>"
        )
    else:
        initial = author[:1] if author else "?"
        avatar_html = f'<div class="df-reviews__avatar df-reviews__avatar--placeholder">{initial}</div>'

    return textwrap.dedent(
        f"""
        <div class="swiper-slide df-reviews__slide">
          {avatar_html}
          <div class="df-reviews__author">{author}</div>
          <div class="df-reviews__stars" aria-label="{review.rating} из 5">{stars}</div>
          <p class="df-reviews__text">{content}</p>
          <span class="df-reviews__source">{source_label}</span>
        </div>
        """
    ).strip()


def generate_liquid(reviews: list[Review]) -> str:
    header = textwrap.dedent(
        """
        {% comment %}
          DanForge — сгенерировано get_reviews.py
          Не редактировать вручную. Перегенерируйте утилитой.
          https://danforge.ru
        {% endcomment %}
        """
    ).strip()

    slides = "\n".join(render_slide(r) for r in reviews)
    return f"{header}\n{slides}\n"


def upload_snippet(cfg: Config, content: str) -> None:
    if not cfg.theme_id:
        themes = fetch_themes(cfg)
        if not themes:
            raise RuntimeError("theme_id не указан и темы не найдены")
        cfg.theme_id = themes[0]["id"]
        print(f"Используется theme_id={cfg.theme_id} ({themes[0].get('title', '')})")

    base, auth = insales_session(cfg)
    url = f"{base}/admin/themes/{cfg.theme_id}/assets.json"
    payloads = [
        {"asset": {"key": SNIPPET_KEY, "content": content}},
        {"asset": {"key": SNIPPET_KEY, "value": content}},
    ]

    last_error = None
    for payload in payloads:
        for method in (requests.put, requests.post):
            resp = method(url, auth=auth, json=payload, timeout=60)
            if resp.status_code in (200, 201):
                print(f"Сниппет загружен: {SNIPPET_KEY}")
                return
            last_error = f"{method.__name__.upper()} {resp.status_code}: {resp.text[:300]}"

    raise RuntimeError(f"Не удалось загрузить сниппет. {last_error}")


def fetch_themes(cfg: Config) -> list[dict]:
    base, auth = insales_session(cfg)
    resp = requests.get(f"{base}/admin/themes.json", auth=auth, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    published = [t for t in data if t.get("isPublished") or t.get("is_published")]
    return published or data


def write_outputs(cfg: Config, liquid: str, all_reviews: list[Review]) -> Path:
    out = Path(cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    liquid_path = out / "danforge_reviews_slides.liquid"
    liquid_path.write_text(liquid, encoding="utf-8")

    cache_path = out / "reviews_cache.json"
    cache_path.write_text(
        json.dumps(
            [
                {
                    "author": r.author,
                    "content": r.content,
                    "rating": r.rating,
                    "source": r.source,
                    "avatar_url": r.avatar_url,
                    "created_at": r.created_at,
                }
                for r in all_reviews
            ],
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(f"Файл: {liquid_path}")
    print(f"Кэш: {cache_path}")
    return liquid_path


def run(cfg: Config, upload: bool) -> None:
    print("Загрузка отзывов inSales…")
    insales = fetch_insales_reviews(cfg)
    print(f"  inSales: {len(insales)} опубликованных")

    print("Загрузка отзывов Яндекс…")
    yandex = fetch_yandex_reviews(cfg)
    print(f"  Яндекс: {len(yandex)}")

    if not insales and not yandex:
        raise SystemExit("Нет отзывов для генерации.")

    picked = sample_reviews(insales, yandex, cfg)
    print(f"В слайдер: {len(picked)} отзывов")

    liquid = generate_liquid(picked)
    write_outputs(cfg, liquid, picked)

    if upload:
        upload_snippet(cfg, liquid)


def build_demo_output(cfg: Config) -> None:
    demo = [
        Review("Анна", "Быстрая доставка, размер подошёл идеально. Буду заказывать ещё!", 5, "insales"),
        Review("Михаил", "Отличный сервис и консультация перед покупкой.", 5, "yandex"),
        Review("Елена", "Качество на высоте, упаковка аккуратная.", 4, "insales"),
    ]
    liquid = generate_liquid(demo)
    write_outputs(cfg, liquid, demo)
    print("Демо-файлы созданы (без API).")


def main() -> None:
    parser = argparse.ArgumentParser(description="DanForge get-reviews")
    parser.add_argument(
        "-c",
        "--config",
        type=Path,
        default=Path(__file__).parent / "config.json",
        help="Путь к config.json",
    )
    parser.add_argument(
        "-u",
        "--upload",
        action="store_true",
        help="Загрузить сниппет в тему inSales",
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Сгенерировать демо-слайды без API",
    )
    args = parser.parse_args()

    if args.demo:
        cfg = Config(
            shop="demo.myinsales.ru",
            api_key="",
            password="",
            output_dir=str(Path(__file__).parent.parent / "output"),
        )
        build_demo_output(cfg)
        return

    if not args.config.exists():
        example = Path(__file__).parent / "config.example.json"
        raise SystemExit(
            f"Создайте {args.config} на основе {example.name}\n"
            "Или запустите: python get_reviews.py --demo"
        )

    cfg = load_config(args.config)
    run(cfg, upload=args.upload)


if __name__ == "__main__":
    main()
