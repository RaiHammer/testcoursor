/**
 * DanForge Reviews Slider — виджет inSales
 * @author DanForge (danforge.ru)
 * @handle danforge_reviews_slider
 */
(function () {
  var root = document.querySelector('[data-df-reviews-slider]');
  if (!root || typeof Swiper === 'undefined') return;

  var enableAutoplay = root.dataset.autoplay !== 'false';
  var delay = parseInt(root.dataset.autoplayDelay, 10) || 5000;

  var config = {
    slidesPerView: 1,
    spaceBetween: 24,
    loop: root.querySelectorAll('.swiper-slide').length > 1,
    pagination: {
      el: root.querySelector('.df-reviews__pagination'),
      clickable: true
    }
  };

  if (enableAutoplay) {
    config.autoplay = { delay: delay, disableOnInteraction: false };
  }

  new Swiper(root, config);
})();
